#Introduction#

**Welcome to Umbraco!**

Umbraco is an information platform that  allows you to quickly and easily publish  information onto  a website without  the need  for any prior knowledge of web page  editing. It is designed to be simple  to use  yet powerful  and flexible enough to enable  users full control  of their website content.

No special skills are required  in order to create, publish  and manage web pages and related content with Umbraco. Any prior web page  editing experience you may have will of course prove useful  in terms of understanding what  you want  your website to do. Anything you can  do using HTML can  also be done  in Umbraco – the functionality is not reduced just because Umbraco is easy  to use.

The Umbraco platform can  be utilised for all types  of websites – from public websites to intranets and extranets, whether password protected or not. It can  even be used  to manage multiple websites from a single Umbraco instance. Regardless of the type, authorisation to edit them  can  be given to anybody  you choose and as editing is done  via a web browser, it can  be done  at any time and in any place.

Umbraco is designed to be intuitive and straight-forward so the aim of this manual is to explain each  step  in simple  terms and get you editing your website with ease.

Happy editing!