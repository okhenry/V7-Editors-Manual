####Tips & Tricks
1. Tips when Working with Folders
2. Audit Trail
3. Changing  Document Types
4. Notifications
5. Preview Pane  Responsive View
6. Session Timeout